"""Dados iniciais que populam o banco na primeira execução.

Depois você troca isso por um cadastro (admin/CRUD) — os dados já estão no banco.
"""

BANNERS = [
    {
        "ordem": 1,
        "titulo": "Back-end & APIs",
        "imagens": [
            "imagens/springboot.png", 
            "imagens/rails.png",
            "imagens/RUBY-LOGO.jpg",
            "imagens/java.png",
            "imagens/node-js-logo.webp",
            "imagens/TOMCAT-LOGO-.jpg",
            "imagens/CI-CD-PIPELINE-001.png",
        ],
        "links": [
            {"label": "API TripBus (Rails)", "url": "#"},
            {"label": "Proway Computers", "url": "#"},
        ],
    },
    {
        "ordem": 2,
        "titulo": "Front-end & Estilo",
        "imagens": [
            "imagens/ANGULAR-LOGO.webp",
            "imagens/TYPESCRIPT-LOGO-.jpg",
            "imagens/TAILWIND-LOGO-.jpg",
            "imagens/node-js-vs-angular.png",
        ],
        "links": [{"label": "Portfólio (este site)", "url": "#"}],
    },
    {
        "ordem": 3,
        "titulo": "Bancos de Dados",
        "imagens": [
            "imagens/postgresql.webp",
            "imagens/MARIA-DB-IMG.png",
            "imagens/APACHE-CASSANDRA.jpg",
            "imagens/KUBERNETES-LOGO.webp",
            "imagens/ALEMBIC-LOGO.PNG",
        ],
        "links": [{"label": "Projeto com PostgreSQL", "url": "#"}],
    },
    {
        "ordem": 4,
        "titulo": "DevOps & Ferramentas",
        "imagens": [
            "imagens/docker-container.webp",
            "imagens/GITHUB-LOGO-.jpg",
            "imagens/NPM-LOGO.png",
            "imagens/POSTMANN-LOGO.png",
            "imagens/python-img.webp",
            "imagens/GIT-LOGO-004.webp",
            "imagens/DEVOPS-ICON.webp",
        ],
        "links": [{"label": "TripBus (Docker)", "url": "#"}],
    },
    {
        "ordem": 5,
        "titulo": "Editores & IDEs",
        "imagens": [
            "imagens/VS-CODE-IMAGE.png",
            "imagens/SUBLIME-LOGO-.jpg",
            "imagens/APACHE-NETBEANS-LOGO.jpg",
            "imagens/VISUALG-LOGO.jpg",
            "imagens/ARGOCD001.webp",
            "imagens/CI-CD-PIPELINE-001.png",
        
        ],
        "links": [{"label": "Em breve", "url": "#"}],
    },
    {
        "ordem": 6,
        "titulo": "Sistemas & Terminal",
        "imagens": [
            "imagens/WINDOWS-LOGO.png",
            "imagens/LINUX-WSL.webp",
            "imagens/POWERSHELL-LOGO.png",
            "imagens/FOTO-SISTEMA-UBUNTU.jpeg",
        ],
        "links": [{"label": "Em breve", "url": "#"}],
    },
    {
        "ordem": 7,
        "titulo": "Do Início ao Intermediário #capgemini",
        "imagens": [
            "imagens/java.jpeg",
            "imagens/APACHE-NETBEANS-LOGO001.png",
            "imagens/NPM-LOGO.png",
            "imagens/LOGO-SASS.png",
            "imagens/INSOMNIA-LOGO.png",
        ],
        "links": [{"label": "Em breve", "url": "#"}],
    },
    {
          "ordem": 8,
          "titulo": "IA Future ",
          "imagens": [
              "imagens/CLAUDE-LOGO.jpg",
              "imagens/IA-FUTURE.png",
           ],
          "links": [{"label": "Em breve", "url": "#"}],
    },
]

PROJETOS = [
    {
        "titulo": "TripBus",
        "descricao": "Sistema de reserva de passagens de ônibus com pagamento integrado via Mercado Pago.",
        "midia": "",
        "tecnologias": ["Ruby on Rails", "PostgreSQL", "Docker", "Angular"],
        "link_demo": "#",
        "link_repo": "#",
    },
    {
        "titulo": "Proway Computers",
        "descricao": "E-commerce de informática com assistente de IA que ajuda o cliente a escolher produtos.",
        "midia": "",
        "tecnologias": ["Rails", "Angular", "Docker", "IA"],
        "link_demo": "#",
        "link_repo": "#",
    },
    {
        "titulo": "Portfólio",
        "descricao": "Este portfólio full-stack: Angular + Tailwind v4 no front e Python (FastAPI) + PostgreSQL no back.",
        "midia": "",
        "tecnologias": ["Angular", "Tailwind", "FastAPI", "PostgreSQL"],
        "link_demo": "#",
        "link_repo": "https://github.com/santhiago4343434343/MULTSTACK-CURRICULAR-PORTIFOLIO-PREVIEW",
    },
    {
        "titulo": "Biblioteca gospel",
        "descricao": "SPA em Angular com TypeScript, estilizada com Sass e testada com Vitest, deploy no GitHub Pages.",
        "midia": "",
        "tecnologias": ["Angular", "Sass", "Node.js", "Vitest"],
        "link_demo": "#",
        "link_repo": "#",
    },
    {
        "titulo": "e-paciente Multstack",
        "descricao": "Java 21 & Spring Boot 4.1 com Spring Security + JWT (stateless, BCrypt), PostgreSQL 16 em produção e H2 em testes, Docker + Docker Compose e script start.sh.",
        "midia": "",
        "tecnologias": ["SpringBoot", "Angular", "Docker", "PostgreSQL", "Tomcat"],
        "link_demo": "#",
        "link_repo": "#",
    },
] 

            