import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { PortfolioService, BannerDTO } from '../../services/portfolio.service';

@Component({
  selector: 'app-banner-detalhe',
  imports: [RouterLink],
  templateUrl: './banner-detalhe.component.html',
  // sem styleUrl: usa só Tailwind
})
export class BannerDetalhe implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(PortfolioService);

  readonly banner = signal<BannerDTO | null>(null);
  readonly carregando = signal(true);

  ngOnInit(): void {
    // reage à mudança do :id na URL (permite ir de um detalhe pro outro)
    this.route.paramMap.subscribe((params) => {
      const id = Number(params.get('id'));
      this.carregando.set(true);
      this.api.getBanner(id).subscribe({
        next: (b) => { this.banner.set(b); this.carregando.set(false); },
        error: () => { this.banner.set(null); this.carregando.set(false); },
      });
    });
  }

  // vídeo (.mp4/.webm) -> <video>; senão <img>
  ehVideo(src: string): boolean {
    return /\.(mp4|webm)$/i.test(src);
  }
}
