   /*Back-end & APIs */

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-detalhe-backend',
    imports: [RouterLink],
    templateUrl: './detalhe-backend.component.html',
})
export class DetalheBackend { }
